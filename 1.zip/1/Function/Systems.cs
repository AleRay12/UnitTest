﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Function
{
    public class Systems
    {
        public double fun (double a, double b, double c, double x)
        {
            double F;
            if (c < 0 && b !=0)
            {
                F = a * Math.Pow(x, 2) + Math.Pow(b, 2) * x;
            }
            else if (c > 0 && b == 0)
            {
                F = (x + a) / (x + c);
            }
            else
            {
                F = (a * x) / (c * Math.Pow(b, 2));
            }
            return F;
        }
    }
}
